require 'puppet/util/feature'

Puppet.features.add(:msgpack, :libs => ["msgpack"])
