require 'puppet/application/indirection_base'

class Puppet::Application::Key < Puppet::Application::IndirectionBase
end
