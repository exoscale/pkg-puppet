require 'puppet/error'

module Puppet::Indirector
  class ValidationError < Puppet::Error; end
end
